library verilog;
use verilog.vl_types.all;
entity forwardUnit is
    port(
        exMemRegWrite   : in     vl_logic;
        exMemRegRd      : in     vl_logic_vector(2 downto 0);
        memWbRedRd      : in     vl_logic_vector(2 downto 0);
        idExRegRs       : in     vl_logic_vector(2 downto 0);
        idExRegRt       : in     vl_logic_vector(2 downto 0);
        fA              : out    vl_logic_vector(1 downto 0);
        fB              : out    vl_logic_vector(1 downto 0)
    );
end forwardUnit;
