library verilog;
use verilog.vl_types.all;
entity hazDetecUnit_vlg_vec_tst is
end hazDetecUnit_vlg_vec_tst;
