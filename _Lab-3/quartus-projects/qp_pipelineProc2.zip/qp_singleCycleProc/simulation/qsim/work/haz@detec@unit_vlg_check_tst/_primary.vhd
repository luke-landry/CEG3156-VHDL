library verilog;
use verilog.vl_types.all;
entity hazDetecUnit_vlg_check_tst is
    port(
        controlMux      : in     vl_logic;
        ifIdWrite       : in     vl_logic;
        pcWrite         : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end hazDetecUnit_vlg_check_tst;
