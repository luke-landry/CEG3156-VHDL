library verilog;
use verilog.vl_types.all;
entity forwardUnit_vlg_check_tst is
    port(
        fA              : in     vl_logic_vector(1 downto 0);
        fB              : in     vl_logic_vector(1 downto 0);
        sampler_rx      : in     vl_logic
    );
end forwardUnit_vlg_check_tst;
