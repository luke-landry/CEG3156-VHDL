library verilog;
use verilog.vl_types.all;
entity hazDetecUnit_vlg_sample_tst is
    port(
        idExMemRead     : in     vl_logic;
        idExRegRt       : in     vl_logic_vector(2 downto 0);
        ifIdRegRs       : in     vl_logic_vector(2 downto 0);
        ifIdRegRt       : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end hazDetecUnit_vlg_sample_tst;
