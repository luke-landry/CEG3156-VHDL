library verilog;
use verilog.vl_types.all;
entity hazDetecUnit is
    port(
        idExMemRead     : in     vl_logic;
        idExRegRt       : in     vl_logic_vector(2 downto 0);
        ifIdRegRs       : in     vl_logic_vector(2 downto 0);
        ifIdRegRt       : in     vl_logic_vector(2 downto 0);
        pcWrite         : out    vl_logic;
        ifIdWrite       : out    vl_logic;
        controlMux      : out    vl_logic
    );
end hazDetecUnit;
