library verilog;
use verilog.vl_types.all;
entity forwardUnit_vlg_sample_tst is
    port(
        exMemRegRd      : in     vl_logic_vector(2 downto 0);
        exMemRegWrite   : in     vl_logic;
        idExRegRs       : in     vl_logic_vector(2 downto 0);
        idExRegRt       : in     vl_logic_vector(2 downto 0);
        memWbRedRd      : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end forwardUnit_vlg_sample_tst;
