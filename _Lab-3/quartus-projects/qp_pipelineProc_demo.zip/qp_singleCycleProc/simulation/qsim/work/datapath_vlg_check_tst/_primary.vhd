library verilog;
use verilog.vl_types.all;
entity datapath_vlg_check_tst is
    port(
        branchOut       : in     vl_logic;
        dbg_ra1         : in     vl_logic_vector(2 downto 0);
        dbg_ra2         : in     vl_logic_vector(2 downto 0);
        dbg_rd1         : in     vl_logic_vector(7 downto 0);
        dbg_rd2         : in     vl_logic_vector(7 downto 0);
        dbg_wa          : in     vl_logic_vector(2 downto 0);
        dbg_wd          : in     vl_logic_vector(7 downto 0);
        instructionOut  : in     vl_logic_vector(31 downto 0);
        memWriteOut     : in     vl_logic;
        muxOut          : in     vl_logic_vector(7 downto 0);
        regWriteOut     : in     vl_logic;
        zeroOut         : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end datapath_vlg_check_tst;
