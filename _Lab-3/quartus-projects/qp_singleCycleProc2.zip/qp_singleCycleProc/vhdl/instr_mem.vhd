library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

library lpm;
use lpm.lpm_components.all;

entity instr_mem is
    port (
        address : in std_logic_vector(7 downto 0);
        clock   : in std_logic;
        q       : out std_logic_vector(31 downto 0)
    );
end entity;

architecture rtl of instr_mem is
begin
    rom_inst : LPM_ROM
        generic map (
            LPM_WIDTH            => 32,
            LPM_WIDTHAD          => 8,
            LPM_NUMWORDS         => 256,
            LPM_ADDRESS_CONTROL  => "REGISTERED",
            LPM_OUTDATA          => "UNREGISTERED",
            LPM_FILE             => "memory/instructions.mif"
        )
        port map (
            ADDRESS   => address,
            INCLOCK   => clock,
            --OUTCLOCK  => clock,
            MEMENAB   => '1',
            Q         => q
        );
end architecture;
