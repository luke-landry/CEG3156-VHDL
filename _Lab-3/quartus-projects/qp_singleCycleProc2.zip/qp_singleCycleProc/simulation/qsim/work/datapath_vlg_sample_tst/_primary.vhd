library verilog;
use verilog.vl_types.all;
entity datapath_vlg_sample_tst is
    port(
        clk             : in     vl_logic;
        reset           : in     vl_logic;
        valueSelect     : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end datapath_vlg_sample_tst;
