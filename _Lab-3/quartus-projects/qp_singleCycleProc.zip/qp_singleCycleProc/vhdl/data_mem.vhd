library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

library lpm;
use lpm.lpm_components.all;

entity data_mem is
    port (
        address : in std_logic_vector(7 downto 0);
        clock   : in std_logic;
        data    : in std_logic_vector(7 downto 0);
        wren    : in std_logic;
        q       : out std_logic_vector(7 downto 0)
    );
end entity;

architecture rtl of data_mem is
begin
    ram_inst: LPM_RAM_DQ
	  generic map (
			LPM_WIDTH            => 8,
			LPM_WIDTHAD          => 8,
			LPM_NUMWORDS         => 256,
			LPM_FILE             => "memory/data.mif",
			LPM_INDATA           => "REGISTERED",
			LPM_ADDRESS_CONTROL  => "REGISTERED",
			LPM_OUTDATA          => "REGISTERED"
	  )
	  port map (
			DATA     => data,
			ADDRESS  => address,
			INCLOCK  => clock,
			OUTCLOCK => clock,
			WE       => wren,
			Q        => q
	  );
end architecture;
