onerror {exit -code 1}
vlib work
vlog -work work singleCycleProc.vo
vlog -work work WaveformPIPELINE.vwf.vt
vsim -novopt -c -t 1ps -L cycloneive_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.datapathPIPELINE_vlg_vec_tst -voptargs="+acc"
vcd file -direction singleCycleProc.msim.vcd
vcd add -internal datapathPIPELINE_vlg_vec_tst/*
vcd add -internal datapathPIPELINE_vlg_vec_tst/i1/*
run -all
quit -f
