library verilog;
use verilog.vl_types.all;
entity aluBlockMSB is
    port(
        a               : in     vl_logic;
        b               : in     vl_logic;
        cIn             : in     vl_logic;
        less            : in     vl_logic;
        aInv            : in     vl_logic;
        bInv            : in     vl_logic;
        op              : in     vl_logic_vector(1 downto 0);
        result          : out    vl_logic;
        cOut            : out    vl_logic;
        set             : out    vl_logic
    );
end aluBlockMSB;
