library verilog;
use verilog.vl_types.all;
entity alu8b_vlg_vec_tst is
end alu8b_vlg_vec_tst;
