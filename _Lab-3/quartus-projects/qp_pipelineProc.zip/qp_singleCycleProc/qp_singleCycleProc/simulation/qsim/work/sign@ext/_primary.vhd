library verilog;
use verilog.vl_types.all;
entity signExt is
    port(
        inp             : in     vl_logic_vector(15 downto 0);
        res             : out    vl_logic_vector(31 downto 0)
    );
end signExt;
