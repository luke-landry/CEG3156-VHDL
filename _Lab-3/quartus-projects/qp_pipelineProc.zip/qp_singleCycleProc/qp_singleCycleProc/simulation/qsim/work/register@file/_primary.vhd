library verilog;
use verilog.vl_types.all;
entity registerFile is
    port(
        clk             : in     vl_logic;
        reset           : in     vl_logic;
        readReg1        : in     vl_logic_vector(2 downto 0);
        readReg2        : in     vl_logic_vector(2 downto 0);
        writeRegister   : in     vl_logic_vector(2 downto 0);
        writeData       : in     vl_logic_vector(7 downto 0);
        regWrite        : in     vl_logic;
        readData1       : out    vl_logic_vector(7 downto 0);
        readData2       : out    vl_logic_vector(7 downto 0)
    );
end registerFile;
