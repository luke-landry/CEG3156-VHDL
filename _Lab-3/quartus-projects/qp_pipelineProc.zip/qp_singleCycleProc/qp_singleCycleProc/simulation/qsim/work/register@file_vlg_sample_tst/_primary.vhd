library verilog;
use verilog.vl_types.all;
entity registerFile_vlg_sample_tst is
    port(
        clk             : in     vl_logic;
        readReg1        : in     vl_logic_vector(2 downto 0);
        readReg2        : in     vl_logic_vector(2 downto 0);
        regWrite        : in     vl_logic;
        reset           : in     vl_logic;
        writeData       : in     vl_logic_vector(7 downto 0);
        writeRegister   : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end registerFile_vlg_sample_tst;
