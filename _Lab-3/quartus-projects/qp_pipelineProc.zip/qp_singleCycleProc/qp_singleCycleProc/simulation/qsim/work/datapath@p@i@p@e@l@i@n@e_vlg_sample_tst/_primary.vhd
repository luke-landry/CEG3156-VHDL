library verilog;
use verilog.vl_types.all;
entity datapathPIPELINE_vlg_sample_tst is
    port(
        clk             : in     vl_logic;
        instrSelect     : in     vl_logic_vector(2 downto 0);
        reset           : in     vl_logic;
        valueSelect     : in     vl_logic_vector(2 downto 0);
        sampler_tx      : out    vl_logic
    );
end datapathPIPELINE_vlg_sample_tst;
