library verilog;
use verilog.vl_types.all;
entity alu8b_vlg_check_tst is
    port(
        result          : in     vl_logic_vector(7 downto 0);
        zero            : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end alu8b_vlg_check_tst;
