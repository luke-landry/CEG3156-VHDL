library verilog;
use verilog.vl_types.all;
entity aluControlUnit_vlg_sample_tst is
    port(
        ALUOp           : in     vl_logic_vector(1 downto 0);
        F               : in     vl_logic_vector(4 downto 0);
        sampler_tx      : out    vl_logic
    );
end aluControlUnit_vlg_sample_tst;
