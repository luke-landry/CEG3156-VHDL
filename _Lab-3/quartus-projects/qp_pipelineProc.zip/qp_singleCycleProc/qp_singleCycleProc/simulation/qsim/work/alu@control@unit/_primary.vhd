library verilog;
use verilog.vl_types.all;
entity aluControlUnit is
    port(
        ALUOp           : in     vl_logic_vector(1 downto 0);
        F               : in     vl_logic_vector(4 downto 0);
        Operation       : out    vl_logic_vector(2 downto 0)
    );
end aluControlUnit;
