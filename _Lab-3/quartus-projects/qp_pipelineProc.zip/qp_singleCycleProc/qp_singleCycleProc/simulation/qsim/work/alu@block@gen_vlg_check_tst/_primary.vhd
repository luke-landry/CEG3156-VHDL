library verilog;
use verilog.vl_types.all;
entity aluBlockGen_vlg_check_tst is
    port(
        cOut            : in     vl_logic;
        result          : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end aluBlockGen_vlg_check_tst;
