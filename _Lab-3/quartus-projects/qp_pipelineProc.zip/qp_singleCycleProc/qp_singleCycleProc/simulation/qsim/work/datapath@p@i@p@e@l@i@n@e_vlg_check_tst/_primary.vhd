library verilog;
use verilog.vl_types.all;
entity datapathPIPELINE_vlg_check_tst is
    port(
        branchOut       : in     vl_logic;
        instructionOut  : in     vl_logic_vector(31 downto 0);
        memWriteOut     : in     vl_logic;
        muxOut          : in     vl_logic_vector(7 downto 0);
        regWriteOut     : in     vl_logic;
        zeroOut         : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end datapathPIPELINE_vlg_check_tst;
