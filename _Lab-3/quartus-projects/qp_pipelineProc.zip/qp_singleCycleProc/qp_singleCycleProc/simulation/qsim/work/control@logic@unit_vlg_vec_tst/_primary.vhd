library verilog;
use verilog.vl_types.all;
entity controlLogicUnit_vlg_vec_tst is
end controlLogicUnit_vlg_vec_tst;
