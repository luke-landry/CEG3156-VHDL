library verilog;
use verilog.vl_types.all;
entity controlLogicUnit_vlg_sample_tst is
    port(
        op              : in     vl_logic_vector(5 downto 0);
        sampler_tx      : out    vl_logic
    );
end controlLogicUnit_vlg_sample_tst;
