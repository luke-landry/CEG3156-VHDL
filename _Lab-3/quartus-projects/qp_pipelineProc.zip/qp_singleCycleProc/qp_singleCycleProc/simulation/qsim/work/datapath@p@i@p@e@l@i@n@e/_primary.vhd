library verilog;
use verilog.vl_types.all;
entity datapathPIPELINE is
    port(
        valueSelect     : in     vl_logic_vector(2 downto 0);
        instrSelect     : in     vl_logic_vector(2 downto 0);
        clk             : in     vl_logic;
        reset           : in     vl_logic;
        muxOut          : out    vl_logic_vector(7 downto 0);
        instructionOut  : out    vl_logic_vector(31 downto 0);
        branchOut       : out    vl_logic;
        zeroOut         : out    vl_logic;
        memWriteOut     : out    vl_logic;
        regWriteOut     : out    vl_logic
    );
end datapathPIPELINE;
