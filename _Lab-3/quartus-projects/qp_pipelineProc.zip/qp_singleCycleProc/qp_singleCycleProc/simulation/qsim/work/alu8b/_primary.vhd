library verilog;
use verilog.vl_types.all;
entity alu8b is
    port(
        a               : in     vl_logic_vector(7 downto 0);
        b               : in     vl_logic_vector(7 downto 0);
        op              : in     vl_logic_vector(2 downto 0);
        zero            : out    vl_logic;
        result          : out    vl_logic_vector(7 downto 0)
    );
end alu8b;
