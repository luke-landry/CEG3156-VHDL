library verilog;
use verilog.vl_types.all;
entity aluControlUnit_vlg_vec_tst is
end aluControlUnit_vlg_vec_tst;
